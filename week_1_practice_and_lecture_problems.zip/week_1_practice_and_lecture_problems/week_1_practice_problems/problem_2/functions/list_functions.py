def create_list_item(item_type, item_name, item_quantity):
    """Creates a dictionary for a shopping list item"""
    returned_dictionary = {'item_type': str(item_type),'item_name': str(item_name), 'item_quantity': str(item_quantity)}

    return returned_dictionary