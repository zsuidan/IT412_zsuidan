import functions.list_functions

shopping_list = []

shopping_list.append(functions.list_functions.create_list_item('food', 'spaghetti', '2'))
shopping_list.append(functions.list_functions.create_list_item('supplies', 'pens', '4'))

print(shopping_list)