from functions.list_functions import create_list_item

shopping_list = []

shopping_list.append(create_list_item('food', 'spaghetti', '2'))
shopping_list.append(create_list_item('supplies', 'pens', '4'))

print(shopping_list)