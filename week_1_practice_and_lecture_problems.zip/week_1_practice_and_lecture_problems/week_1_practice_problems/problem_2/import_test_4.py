import functions.list_functions as shopping_functions

shopping_list = []

shopping_list.append(shopping_functions.create_list_item('food', 'spaghetti', '2'))
shopping_list.append(shopping_functions.create_list_item('supplies', 'pens', '4'))

print(shopping_list)