from classes.shirt import Shirt

my_shirt = Shirt("M", "Red")
print(my_shirt.size)
print(my_shirt.color)

my_shirt.getShirtInfo()

my_other_shirt = Shirt("L", "Blue")
print(my_other_shirt.size)
print(my_other_shirt.color)

my_other_shirt.getShirtInfo()