from functions.function_library import *

#Prompts the user to enter information for a date and creates a date in the proper format
user_date = get_date()

#Prints the date entered by the user
print(user_date)